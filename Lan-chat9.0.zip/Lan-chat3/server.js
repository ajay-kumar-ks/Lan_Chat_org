const express = require("express");
const mysql = require("mysql2");
const path = require("path");
const multer = require("multer");
const fs = require("fs");

const app = express();
const PORT = 3000;

// ✅ MySQL Connection
const db = mysql.createConnection({
  host: "localhost",
  user: "chatuser",
  password: "123",
  database: "chat_app",
  charset: "utf8mb4",
});

db.connect((err) => {
  if (err) throw err;
  console.log("✅ MySQL connected");
});``

// ✅ File Upload Setup
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9) + ext;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage,
  fileFilter: function (req, file, cb) {
    const allowed = [
      "image/jpeg", "image/png", "image/gif",
      "video/mp4", "video/webm", "video/ogg",
      "application/pdf"
    ];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error("Unsupported file type"));
  }
});


// ✅ Middleware
app.use(express.static(__dirname));
app.use("/uploads", express.static(uploadDir));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(express.json({ limit: "10mb" }));

// ✅ Serve main page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// ✅ Get messages
app.get("/messages", (req, res) => {
  db.query("SELECT * FROM messages ORDER BY created_at DESC", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// ✅ Check if given ID matches latest message ID
app.post("/check-last-id", (req, res) => {
  const { id } = req.body;

  if (!id) {
    return res.status(400).json({ error: "ID is required" });
  }

  db.query(
    "SELECT id FROM messages ORDER BY id DESC LIMIT 1",
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });

      if (results.length === 0) {
        return res.json({ match: false }); // no messages yet
      }

      const lastId = results[0].id;

      res.json({ match: Number(id) === lastId });
    }
  );
});

const uploadMultiple = upload.array("photos", 5); // max 5 images per message

// ✅ Post message
app.post("/messages", (req, res) => {
  uploadMultiple(req, res, (err) => {
    if (err) return res.status(500).json({ error: err.message });

    const username = req.body.username;
    const message = req.body.message || "";
    const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
    const imageUrls = (req.files || []).map(f => "/uploads/" + f.filename);

    if (!username || (!message && imageUrls.length === 0))
      return res.status(400).json({ error: "Missing username or message" });

    // ✅ Special message to clear all messages
    if (message.trim() === "3333") {
      db.query("DELETE FROM messages", (err) => {
        if (err) throw err;
        console.log(`${username} (${ip}) -- chat cleared`);
        return res.json({ success: true, cleared: true });
      });
      return;
    }

    db.query(
      "INSERT INTO messages (username, message, ip_address, image_url) VALUES (?, ?, ?, ?)",
      [username, message, ip, imageUrls.join(",")],
      (err) => {
        if (err) throw err;
        console.log(`${username} (${ip}) -- ${message}`);
        res.json({ success: true });
      }
    );
  });
});
app.get("/game-score/:game", (req,res)=>{

  const game = req.params.game;

  db.query(
    "SELECT player_name, score FROM game_scores WHERE game_name=? ORDER BY score DESC LIMIT 10",
    [game],
    (err,result)=>{
      if(err) throw err;
      res.json(result);
    }
  );

});
app.post("/game-score",(req,res)=>{

  const {game, name, score} = req.body;

  db.query(
    "INSERT INTO game_scores (game_name, player_name, score) VALUES (?,?,?)",
    [game,name,score],
    (err)=>{
      if(err) throw err;
      res.json({success:true});
    }
  );

});
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});


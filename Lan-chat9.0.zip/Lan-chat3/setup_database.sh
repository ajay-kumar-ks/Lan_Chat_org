#!/bin/bash

set -e

DB_NAME="chat_app"
DB_USER="chatuser"
DB_PASS="123"

echo "=== Starting MySQL/MariaDB ==="

if systemctl list-unit-files | grep -q "^mariadb"; then
    sudo systemctl start mariadb
elif systemctl list-unit-files | grep -q "^mysql"; then
    sudo systemctl start mysql
else
    echo "❌ MySQL/MariaDB is not installed."
    exit 1
fi

echo "=== Configuring database ==="

sudo mysql <<EOF

CREATE DATABASE IF NOT EXISTS ${DB_NAME}
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost'
IDENTIFIED BY '${DB_PASS}';

ALTER USER '${DB_USER}'@'localhost'
IDENTIFIED BY '${DB_PASS}';

GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';

FLUSH PRIVILEGES;

USE ${DB_NAME};

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    message TEXT,
    ip_address VARCHAR(45),
    image_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS game_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_name VARCHAR(100) NOT NULL,
    player_name VARCHAR(100) NOT NULL,
    score INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_messages_created_at
ON messages(created_at);

CREATE INDEX IF NOT EXISTS idx_game_name_score
ON game_scores(game_name, score DESC);

EOF

echo ""
echo "=================================="
echo "Database setup completed!"
echo "Database : ${DB_NAME}"
echo "User     : ${DB_USER}"
echo "Password : ${DB_PASS}"
echo "=================================="

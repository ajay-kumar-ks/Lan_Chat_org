-- CREATE TABLE game_scores (
--   id INT AUTO_INCREMENT PRIMARY KEY,
--   game_name VARCHAR(50),
--   player_name VARCHAR(50),
--   score INT,
--   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );

CREATE DATABASE chat_app
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE chat_app;

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    message TEXT,
    ip_address VARCHAR(45),
    image_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE game_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_name VARCHAR(100) NOT NULL,
    player_name VARCHAR(100) NOT NULL,
    score INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_messages_created_at
ON messages(created_at);

CREATE INDEX idx_game_name_score
ON game_scores(game_name, score DESC);

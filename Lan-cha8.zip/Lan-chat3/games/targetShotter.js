const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let score = 0;
let timeLeft = 30;

let target = {
    x:100,
    y:100,
    radius:25
};

/* move target */

function moveTarget(){

    target.x = Math.random()*(canvas.width-60) + 30;
    target.y = Math.random()*(canvas.height-60) + 30;

}

setInterval(moveTarget,1000);

/* click detection */

canvas.addEventListener("click",(e)=>{

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const dx = mouseX - target.x;
    const dy = mouseY - target.y;

    const distance = Math.sqrt(dx*dx + dy*dy);

    if(distance < target.radius){

        score += 10;
        document.getElementById("score").innerText = "Score: " + score;

        moveTarget();

    }

});

/* timer */

const timer = setInterval(()=>{

    timeLeft--;

    document.getElementById("time").innerText = "Time: " + timeLeft;

    if(timeLeft <= 0){

        clearInterval(timer);
        alert("Game Over! Score: " + score);
        location.reload();

    }

},1000);

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* target */

    ctx.beginPath();
    ctx.arc(target.x,target.y,target.radius,0,Math.PI*2);
    ctx.fillStyle="red";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(target.x,target.y,10,0,Math.PI*2);
    ctx.fillStyle="white";
    ctx.fill();

    requestAnimationFrame(draw);

}

draw();
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let towers = [];
let enemies = [];
let bullets = [];

let score = 0;

/* path */

const path = [
{x:0,y:250},
{x:200,y:250},
{x:200,y:100},
{x:500,y:100},
{x:500,y:400},
{x:800,y:400}
];

/* place tower */

canvas.addEventListener("click",(e)=>{

    const rect = canvas.getBoundingClientRect();

    towers.push({
        x:e.clientX - rect.left,
        y:e.clientY - rect.top,
        range:120
    });

});

/* spawn enemies */

function spawnEnemy(){

    enemies.push({
        x:path[0].x,
        y:path[0].y,
        pathIndex:0,
        health:3,
        speed:1
    });

}

setInterval(spawnEnemy,2000);

/* update */

function update(){

    /* move enemies */

    enemies.forEach((enemy,ei)=>{

        let target = path[enemy.pathIndex+1];

        if(!target) return;

        let dx = target.x - enemy.x;
        let dy = target.y - enemy.y;

        let dist = Math.sqrt(dx*dx + dy*dy);

        enemy.x += dx/dist * enemy.speed;
        enemy.y += dy/dist * enemy.speed;

        if(dist < 5){
            enemy.pathIndex++;
        }

        if(enemy.pathIndex >= path.length-1){

            enemies.splice(ei,1);

        }

    });

    /* tower shooting */

    towers.forEach(tower=>{

        enemies.forEach(enemy=>{

            let dx = enemy.x - tower.x;
            let dy = enemy.y - tower.y;

            let dist = Math.sqrt(dx*dx + dy*dy);

            if(dist < tower.range){

                bullets.push({
                    x:tower.x,
                    y:tower.y,
                    target:enemy
                });

            }

        });

    });

    /* bullet movement */

    bullets.forEach((b,bi)=>{

        if(!b.target) return;

        let dx = b.target.x - b.x;
        let dy = b.target.y - b.y;

        let dist = Math.sqrt(dx*dx + dy*dy);

        b.x += dx/dist * 5;
        b.y += dy/dist * 5;

        if(dist < 10){

            b.target.health--;

            if(b.target.health <= 0){

                let index = enemies.indexOf(b.target);

                if(index > -1){

                    enemies.splice(index,1);

                    score += 10;

                    document.getElementById("score").innerText =
                    "Score: " + score;

                }

            }

            bullets.splice(bi,1);

        }

    });

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* path */

    ctx.strokeStyle="gray";
    ctx.lineWidth=40;

    ctx.beginPath();
    ctx.moveTo(path[0].x,path[0].y);

    path.forEach(p=>{
        ctx.lineTo(p.x,p.y);
    });

    ctx.stroke();

    /* towers */

    ctx.fillStyle="cyan";

    towers.forEach(t=>{
        ctx.beginPath();
        ctx.arc(t.x,t.y,15,0,Math.PI*2);
        ctx.fill();
    });

    /* enemies */

    ctx.fillStyle="red";

    enemies.forEach(e=>{
        ctx.beginPath();
        ctx.arc(e.x,e.y,12,0,Math.PI*2);
        ctx.fill();
    });

    /* bullets */

    ctx.fillStyle="yellow";

    bullets.forEach(b=>{
        ctx.beginPath();
        ctx.arc(b.x,b.y,5,0,Math.PI*2);
        ctx.fill();
    });

}

/* loop */

function loop(){

    update();
    draw();

    requestAnimationFrame(loop);

}

loop();

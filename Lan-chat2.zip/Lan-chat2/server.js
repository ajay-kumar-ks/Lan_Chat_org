const express = require("express");
const mysql = require("mysql2");
const path = require("path");
const multer = require("multer");
const fs = require("fs");

const app = express();
const PORT = 3000;

// ✅ MySQL Connection
const db = mysql.createConnection({
  host: "localhost",
  user: "nodeuser",
  password: "mypass123",
  database: "chat_app",
  charset: "utf8mb4", // ✅ ensures all Unicode characters are stored
});

db.connect((err) => {
  if (err) throw err;
  console.log("✅ MySQL connected");
});

// ✅ File Upload Setup
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9) + ext;
    cb(null, uniqueName);
  },
});

const upload = multer({ storage });

// ✅ Middleware
app.use(express.static(__dirname));
app.use("/uploads", express.static(uploadDir));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(express.json({ limit: "10mb" }));

// ✅ Serve main page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// ✅ Get messages
app.get("/messages", (req, res) => {
  db.query("SELECT * FROM messages ORDER BY created_at DESC", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// ✅ Post message
app.post("/messages", upload.single("photo"), (req, res) => {
  const username = req.body.username;
  const message = req.body.message || "";
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
  let imageUrl = "";

  if (req.file) imageUrl = "/uploads/" + req.file.filename;
  if (!username || (!message && !imageUrl))
    return res.status(400).json({ error: "Missing username or message" });

  if (message.trim() === "1111") {
    db.query("DELETE FROM messages", (err) => {
      if (err) throw err;
      console.log(`🧹 Chat cleared by ${username}`);
      return res.json({ success: true, cleared: true });
    });
    return;
  }

  db.query(
    "INSERT INTO messages (username, message, ip_address, image_url) VALUES (?, ?, ?, ?)",
    [username, message, ip, imageUrl],
    (err) => {
      if (err) throw err;
      console.log(`📩 ${username}: message saved (${message.length} chars)`);
      res.json({ success: true });
    }
  );
});

// ✅ Start server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});

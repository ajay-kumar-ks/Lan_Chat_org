let number = 0;
let score = 0;

const playBtn = document.getElementById("playBtn");
const gameArea = document.getElementById("gameArea");

playBtn.onclick = () => {

    number = Math.floor(Math.random()*10)+1;
    gameArea.style.display="block";

}
function loadScores(){

fetch("/game-score/guess")
.then(res=>res.json())
.then(data=>{

const list=document.getElementById("scores");

list.innerHTML="";

data.forEach(s=>{

const li=document.createElement("li");
li.textContent = s.player_name + " - " + s.score;

list.appendChild(li);

});

});

}

function saveScore(){

fetch("/game-score",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
game:"guess",
name:playerName,
score:score
})
}).then(loadScores);

}

function submitGuess(){

    const guess = Number(document.getElementById("guessInput").value);

    const result = document.getElementById("result");

    if(guess === number){

        score++;
        result.innerText="🎉 Correct!";
        document.getElementById("score").innerText=score;

        number = Math.floor(Math.random()*10)+1;

    }else{

        result.innerText="❌ Wrong! Try again.";

    }

}
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const paddleHeight = 10;
const paddleWidth = 100;

let paddleX = (canvas.width - paddleWidth) / 2;

let ballX = canvas.width / 2;
let ballY = canvas.height - 30;

let dx = 3;
let dy = -3;

let score = 0;
let level = 1;
let running = false;

let playerName = "";

const scoreEl = document.getElementById("score");
const levelEl = document.getElementById("level");

document.getElementById("playBtn").onclick = () => {

    playerName = document.getElementById("playerName").value.trim();

    if (!playerName) {
        alert("Enter name");
        return;
    }

    resetGame();
    running = true;

};

function resetGame() {

    score = 0;
    level = 1;

    ballX = canvas.width / 2;
    ballY = canvas.height - 30;

    dx = 3;
    dy = -3;

    createBricks();

}

canvas.addEventListener("mousemove", e => {

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;

    paddleX = mouseX - paddleWidth / 2;

    // keep paddle inside canvas
    if (paddleX < 0) paddleX = 0;
    if (paddleX + paddleWidth > canvas.width)
        paddleX = canvas.width - paddleWidth;

});

const brickRowCount = 4;
const brickColumnCount = 7;

let bricks = [];

function createBricks() {

    bricks = [];

    for (let c = 0; c < brickColumnCount; c++) {

        bricks[c] = [];

        for (let r = 0; r < brickRowCount; r++) {

            bricks[c][r] = { x: 0, y: 0, status: 1 };

        }
    }
}

createBricks();

function drawBall() {

    ctx.beginPath();
    ctx.arc(ballX, ballY, 8, 0, Math.PI * 2);
    ctx.fillStyle = "white";
    ctx.fill();
    ctx.closePath();

}

function drawPaddle() {

    ctx.beginPath();
    ctx.rect(paddleX, canvas.height - paddleHeight, paddleWidth, paddleHeight);
    ctx.fillStyle = "lime";
    ctx.fill();
    ctx.closePath();

}

function drawBricks() {

    for (let c = 0; c < brickColumnCount; c++) {

        for (let r = 0; r < brickRowCount; r++) {

            if (bricks[c][r].status == 1) {

                let brickX = (c * 75) + 30;
                let brickY = (r * 20) + 30;

                bricks[c][r].x = brickX;
                bricks[c][r].y = brickY;

                ctx.beginPath();
                ctx.rect(brickX, brickY, 60, 15);
                ctx.fillStyle = "orange";
                ctx.fill();
                ctx.closePath();

            }
        }
    }
}

function collision() {

    for (let c = 0; c < brickColumnCount; c++) {

        for (let r = 0; r < brickRowCount; r++) {

            let b = bricks[c][r];

            if (b.status == 1) {

                if (
                    ballX > b.x &&
                    ballX < b.x + 60 &&
                    ballY > b.y &&
                    ballY < b.y + 15
                ) {

                    dy = -dy;
                    b.status = 0;
                    score += 10;

                    // level up every 100
                    if (score % 100 === 0) {

                        level++;
                        dx *= 1.2;
                        dy *= 1.2;

                    }

                }
            }
        }
    }
}

function draw() {

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawBricks();
    drawBall();
    drawPaddle();

    collision();

    scoreEl.textContent = score;
    levelEl.textContent = level;

    if (running) {

        if (ballX + dx > canvas.width - 8 || ballX + dx < 8)
            dx = -dx;

        if (ballY + dy < 8)
            dy = -dy;

        else if (ballY + dy > canvas.height - 8) {

            if (ballX > paddleX && ballX < paddleX + paddleWidth) {

                dy = -dy;

            } else {

                running = false;

                saveScore();

                alert("Game Over! Score: " + score);

            }
        }

        ballX += dx;
        ballY += dy;

    }

    requestAnimationFrame(draw);

}

draw();

function saveScore() {

    fetch("/game-score", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            game: "bounce",
            name: playerName,
            score: score
        })
    }).then(loadScores);

}

function loadScores() {

    fetch("/game-score/bounce")
        .then(res => res.json())
        .then(data => {

            const list = document.getElementById("scores");
            list.innerHTML = "";

            data.forEach(s => {

                const li = document.createElement("li");
                li.textContent = s.player_name + " - " + s.score;

                list.appendChild(li);

            });

        });

}

loadScores();
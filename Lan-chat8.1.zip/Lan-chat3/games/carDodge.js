const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player = {
    x:220,
    y:500,
    width:60,
    height:100
};

let enemies = [];

let score = 0;
let speed = 3;
let gameOver = false;

let playerName = "";
let gameStarted = false;
let scoreSaved = false;
/* mouse movement */

canvas.addEventListener("mousemove",(e)=>{

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;

    player.x = mouseX - player.width/2;

    if(player.x < 0) player.x = 0;
    if(player.x > canvas.width-player.width)
        player.x = canvas.width-player.width;

});

/* spawn enemy cars */

function spawnEnemy(){

    enemies.push({
        x:Math.random()*(canvas.width-60),
        y:-120,
        width:60,
        height:100
    });

}


setInterval(spawnEnemy,1200);

function loadScores() {
    fetch("/game-score/car")
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("scores");
            list.innerHTML = "";

            data.sort((a,b)=>b.score-a.score);

            data.slice(0,10).forEach(s => {
                const li = document.createElement("li");
                li.textContent = s.player_name + " - " + s.score;
                list.appendChild(li);
            });
        });
}

function saveScore() {
    if(scoreSaved) return;

    fetch("/game-score", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            game: "car",
            name: playerName,
            score: score
        })
    }).then(() => {
        scoreSaved = true;
        loadScores();
    });
}

document.getElementById("startBtn").onclick = () => {
    playerName = document.getElementById("playerName").value.trim();

    if(!playerName){
        alert("Enter name");
        return;
    }

    gameStarted = true;
};

/* update */

function update(){

    if(gameOver) return;

    enemies.forEach((e,i)=>{

        e.y += speed;

        if(
            player.x < e.x + e.width &&
            player.x + player.width > e.x &&
            player.y < e.y + e.height &&
            player.y + player.height > e.y
        ){

            gameOver = true;

            saveScore();
            alert("Crash! Score: " + score);
            location.reload();

        }

        if(e.y > canvas.height){
            enemies.splice(i,1);
        }

    });

    score++;

    document.getElementById("score").innerText =
    "Score: " + score;

    speed = 3 + score/200;

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* road lines */

    ctx.strokeStyle="white";
    ctx.setLineDash([20,20]);
    ctx.lineWidth=4;

    ctx.beginPath();
    ctx.moveTo(canvas.width/2,0);
    ctx.lineTo(canvas.width/2,canvas.height);
    ctx.stroke();

    ctx.setLineDash([]);

    /* player */

    ctx.fillStyle="cyan";
    ctx.fillRect(player.x,player.y,player.width,player.height);

    /* enemy cars */

    ctx.fillStyle="red";

    enemies.forEach(e=>{
        ctx.fillRect(e.x,e.y,e.width,e.height);
    });

}

/* game loop */

function loop(){

    if(!gameStarted){
        requestAnimationFrame(loop);
        return;
    }

    update();
    draw();

    requestAnimationFrame(loop);
}
loadScores();
loop();
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player = {
  x: 350,
  y: 250,
  size: 20,
};

let bullets = [];
let zombies = [];

let score = 0;
let gameOver = false;
let gameStarted = false;
let playerName = "";

/* =========================
   START BUTTON
========================= */
document.getElementById("startBtn").onclick = () => {
  playerName = document.getElementById("playerName").value.trim();

  if (!playerName) {
    alert("Enter name");
    return;
  }

  document.getElementById("startScreen").style.display = "none";

  gameStarted = true;
  startSpawning();
};

/* =========================
   PLAYER MOVEMENT
========================= */
canvas.addEventListener("mousemove", (e) => {
  if (!gameStarted) return;

  const rect = canvas.getBoundingClientRect();

  player.x = e.clientX - rect.left;
  player.y = e.clientY - rect.top;
});

/* =========================
   SHOOTING
========================= */
canvas.addEventListener("click", () => {
  if (!gameStarted) return;

  bullets.push({
    x: player.x,
    y: player.y,
    speed: 6,
  });
});

/* =========================
   SPAWN ZOMBIES
========================= */
let spawnInterval;

function spawnZombie() {
  const side = Math.floor(Math.random() * 4);
  let x, y;

  if (side === 0) {
    x = Math.random() * canvas.width;
    y = -30;
  } else if (side === 1) {
    x = canvas.width + 30;
    y = Math.random() * canvas.height;
  } else if (side === 2) {
    x = Math.random() * canvas.width;
    y = canvas.height + 30;
  } else {
    x = -30;
    y = Math.random() * canvas.height;
  }

  zombies.push({
    x: x,
    y: y,
    size: 25,
    speed: 1.5,
  });
}

function startSpawning() {
  spawnInterval = setInterval(() => {
    if (!gameStarted) return;
    spawnZombie();
  }, 1000);
}

/* =========================
   UPDATE
========================= */
function update() {
  if (!gameStarted || gameOver) return;

  bullets.forEach((b, bi) => {
    b.y -= b.speed;

    if (b.y < 0) {
      bullets.splice(bi, 1);
    }
  });

  zombies.forEach((z, zi) => {
    const dx = player.x - z.x;
    const dy = player.y - z.y;
    const dist = Math.sqrt(dx * dx + dy * dy);

    z.x += (dx / dist) * z.speed;
    z.y += (dy / dist) * z.speed;

    /* player hit */
    if (dist < z.size) {
      endGame();
    }

    /* bullet hit */
    bullets.forEach((b, bi) => {
      const dx2 = b.x - z.x;
      const dy2 = b.y - z.y;
      const d = Math.sqrt(dx2 * dx2 + dy2 * dy2);

      if (d < z.size) {
        zombies.splice(zi, 1);
        bullets.splice(bi, 1);

        score += 10;

        document.getElementById("score").innerText =
          "Score: " + score;
      }
    });
  });
}

/* =========================
   GAME OVER
========================= */
function endGame() {
  gameOver = true;
  gameStarted = false;

  clearInterval(spawnInterval);

  saveScore();

  alert("Game Over! Score: " + score);
  location.reload();
}

/* =========================
   DRAW
========================= */
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  /* player */
  ctx.beginPath();
  ctx.arc(player.x, player.y, player.size, 0, Math.PI * 2);
  ctx.fillStyle = "cyan";
  ctx.fill();

  /* bullets */
  ctx.fillStyle = "yellow";
  bullets.forEach((b) => {
    ctx.beginPath();
    ctx.arc(b.x, b.y, 5, 0, Math.PI * 2);
    ctx.fill();
  });

  /* zombies */
  ctx.fillStyle = "green";
  zombies.forEach((z) => {
    ctx.beginPath();
    ctx.arc(z.x, z.y, z.size, 0, Math.PI * 2);
    ctx.fill();
  });
}

/* =========================
   LOOP
========================= */
function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

loop();

/* =========================
   LEADERBOARD
========================= */
function loadScores() {
  fetch("/game-score/zombie")
    .then((res) => res.json())
    .then((data) => {
      const list = document.getElementById("scores");
      list.innerHTML = "";

      data.sort((a, b) => b.score - a.score);

      data.forEach((s, index) => {
        const li = document.createElement("li");
        li.textContent =
          (index + 1) + ". " + s.player_name + " - " + s.score;
        list.appendChild(li);
      });
    })
    .catch(() => console.log("Leaderboard error"));
}

function saveScore() {
  fetch("/game-score", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      game: "zombie",
      name: playerName,
      score: score,
    }),
  }).then(loadScores);
}

/* =========================
   INIT
========================= */
loadScores();
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const size = 20;
const tile = canvas.width / size;

let maze = [];
let level = 1;
let timeLeft = 60;

let player = {x:0,y:0};
let exit = {x:size-1,y:size-1};

let enemies = [];

let playerName = "";
let gameStarted = false;
let scoreSaved = false;

let startTime = 0;
let endTime = 0;

/* random maze */

function generateMaze(){

    do{

        maze = [];

        for(let y=0;y<size;y++){

            maze[y] = [];

            for(let x=0;x<size;x++){

                maze[y][x] = Math.random() < 0.28 ? 1 : 0;

            }

        }

        maze[0][0] = 0;
        maze[size-1][size-1] = 0;

    } while(!pathExists());

}

function pathExists(){

    let visited = [];
    let queue = [{x:0,y:0}];

    for(let y=0;y<size;y++){
        visited[y] = [];
        for(let x=0;x<size;x++){
            visited[y][x] = false;
        }
    }

    visited[0][0] = true;

    const dirs = [
        [0,1],[1,0],[0,-1],[-1,0]
    ];

    while(queue.length > 0){

        let current = queue.shift();

        if(current.x === size-1 && current.y === size-1){
            return true;
        }

        for(let d of dirs){

            let nx = current.x + d[0];
            let ny = current.y + d[1];

            if(
                nx >= 0 &&
                ny >= 0 &&
                nx < size &&
                ny < size &&
                !visited[ny][nx] &&
                maze[ny][nx] === 0
            ){

                visited[ny][nx] = true;
                queue.push({x:nx,y:ny});

            }

        }

    }

    return false;

}

function loadScores() {
    fetch("/game-score/maze")
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("scores");
            list.innerHTML = "";

            // 🔥 sort by LOWEST time (fastest first)
            data.sort((a,b)=>a.score - b.score);

            data.slice(0,10).forEach(s => {
                const li = document.createElement("li");
                li.textContent = s.player_name + " - " + s.score + "s";
                list.appendChild(li);
            });
        });
}

function saveScore(timeTaken) {
    if(scoreSaved) return;

    fetch("/game-score", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            game: "maze",
            name: playerName,
            score: timeTaken // ⏱ store time instead of points
        })
    }).then(() => {
        scoreSaved = true;
        loadScores();
    });
}

document.getElementById("startBtn").onclick = () => {
    playerName = document.getElementById("playerName").value.trim();

    if(!playerName){
        alert("Enter name");
        return;
    }

    gameStarted = true;
    scoreSaved = false;

    startTime = Date.now(); // ⏱ start timer
};

/* create enemies */

function spawnEnemies(){

    enemies = [];

    for(let i=0;i<level;i++){

        enemies.push({
            x:Math.floor(Math.random()*size),
            y:Math.floor(Math.random()*size)
        });

    }

}

/* start level */

function startLevel(){

    generateMaze();

    player.x = 0;
    player.y = 0;

    spawnEnemies();

    document.getElementById("level").innerText = level;

}

startLevel();

/* movement */

document.addEventListener("keydown",(e)=>{

    let nx = player.x;
    let ny = player.y;

    if(e.key === "ArrowUp") ny--;
    if(e.key === "ArrowDown") ny++;
    if(e.key === "ArrowLeft") nx--;
    if(e.key === "ArrowRight") nx++;

    if(
        nx >= 0 &&
        ny >= 0 &&
        nx < size &&
        ny < size &&
        maze[ny][nx] === 0
    ){
        player.x = nx;
        player.y = ny;
    }

   if(player.x === exit.x && player.y === exit.y){
        level++;
        timeLeft += 10;

        // Optional: end game after a fixed number of levels
        if(level > 5){ // for example
            gameOver(true);
            return;
        }

        startLevel();
    }

});

/* enemy movement */

function moveEnemies(){

    enemies.forEach(e=>{

        let dir = Math.floor(Math.random()*4);

        let nx = e.x;
        let ny = e.y;

        if(dir === 0) ny--;
        if(dir === 1) ny++;
        if(dir === 2) nx--;
        if(dir === 3) nx++;

        if(
            nx >= 0 &&
            ny >= 0 &&
            nx < size &&
            ny < size &&
            maze[ny][nx] === 0
        ){
            e.x = nx;
            e.y = ny;
        }

        if(e.x === player.x && e.y === player.y){
            gameOver(false);
            alert("👾 Enemy caught you!");
            location.reload();

        }

    });

}

setInterval(moveEnemies,500);

/* timer */

setInterval(()=>{
    if(!gameStarted) return;
    timeLeft--;
    document.getElementById("time").innerText = timeLeft;

    if(timeLeft <= 0){
        gameOver(false);
        location.reload();
    }
},1000);

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    for(let y=0;y<size;y++){

        for(let x=0;x<size;x++){

            if(maze[y][x] === 1){

                ctx.fillStyle="#333";
                ctx.fillRect(x*tile,y*tile,tile,tile);

            }else{

                ctx.fillStyle="#111";
                ctx.fillRect(x*tile,y*tile,tile,tile);

            }

        }

    }

    /* exit */

    ctx.fillStyle="green";
    ctx.fillRect(exit.x*tile,exit.y*tile,tile,tile);

    /* player */

    ctx.fillStyle="cyan";
    ctx.fillRect(player.x*tile,player.y*tile,tile,tile);

    /* enemies */

    ctx.fillStyle="red";

    enemies.forEach(e=>{
        ctx.fillRect(e.x*tile,e.y*tile,tile,tile);
    });

}

/* loop */

function loop(){

    draw();
    requestAnimationFrame(loop);

}

function gameOver(success) {
    endTime = Date.now();
    const timeTaken = Math.floor((endTime - startTime) / 1000);

    // Score: combine time & levels (faster and higher level = lower score)
    const score = timeTaken - level * 5; // adjust multiplier as you like

    if(success){
        alert(`🎉 You escaped the maze in ${timeTaken}s at level ${level}!`);
    } else {
        alert(`⏱ Game Over! You reached level ${level} in ${timeTaken}s`);
    }

    saveScore(score);
}
function moveEnemies() {
    if(!gameStarted) return; // 🚫 no enemies before game starts

    enemies.forEach(e => {
        let dir = Math.floor(Math.random() * 4);
        let nx = e.x;
        let ny = e.y;

        if(dir === 0) ny--;
        if(dir === 1) ny++;
        if(dir === 2) nx--;
        if(dir === 3) nx++;

        if(nx >= 0 && ny >= 0 && nx < size && ny < size && maze[ny][nx] === 0){
            e.x = nx;
            e.y = ny;
        }

        if(e.x === player.x && e.y === player.y){
            gameOver(false);
            location.reload();
        }
    });
}

document.getElementById("startBtn").onclick = () => {
    playerName = document.getElementById("playerName").value.trim();

    if(!playerName){
        alert("Enter name");
        return;
    }

    gameStarted = true; // ✅ now the game is active
    scoreSaved = false;

    startTime = Date.now(); // ⏱ start timer here
};
setInterval(moveEnemies, 500);


window.onload = () => {
    loadScores();
};
loop();

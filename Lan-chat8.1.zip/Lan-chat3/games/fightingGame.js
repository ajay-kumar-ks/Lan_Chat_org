const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let p1 = {
    x:150,
    y:350,
    width:50,
    height:80,
    health:100
};

let p2 = {
    x:600,
    y:350,
    width:50,
    height:80,
    health:100
};

let keys = {};

/* keyboard */

document.addEventListener("keydown",(e)=>{
    keys[e.key] = true;
});

document.addEventListener("keyup",(e)=>{
    keys[e.key] = false;
});

/* update */

function update(){

    /* player1 movement */

    if(keys["a"]) p1.x -= 5;
    if(keys["d"]) p1.x += 5;

    /* player2 movement */

    if(keys["ArrowLeft"]) p2.x -= 5;
    if(keys["ArrowRight"]) p2.x += 5;

    /* player1 attack */

    if(keys["w"]){

        if(Math.abs(p1.x - p2.x) < 70){

            p2.health -= 1;

            document.getElementById("p2").innerText = p2.health;

        }

    }

    /* player2 attack */

    if(keys["ArrowUp"]){

        if(Math.abs(p1.x - p2.x) < 70){

            p1.health -= 1;

            document.getElementById("p1").innerText = p1.health;

        }

    }

    /* win */

    if(p1.health <= 0){

        alert("Player 2 Wins!");
        location.reload();

    }

    if(p2.health <= 0){

        alert("Player 1 Wins!");
        location.reload();

    }

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* ground */

    ctx.fillStyle="#333";
    ctx.fillRect(0,430,800,20);

    /* player1 */

    ctx.fillStyle="cyan";
    ctx.fillRect(p1.x,p1.y,p1.width,p1.height);

    /* player2 */

    ctx.fillStyle="red";
    ctx.fillRect(p2.x,p2.y,p2.width,p2.height);

}

/* game loop */

function loop(){

    update();
    draw();

    requestAnimationFrame(loop);

}

loop();

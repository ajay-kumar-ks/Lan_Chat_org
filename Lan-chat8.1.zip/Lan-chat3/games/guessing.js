const board = document.getElementById("board");

let level = 1;
let score = 0;
let expected = 1;
let running = false;

let playerName = "";

const levelEl = document.getElementById("level");
const scoreEl = document.getElementById("score");

document.getElementById("playBtn").onclick = () => {

playerName = document.getElementById("playerName").value.trim();

if(!playerName){
alert("Enter name");
return;
}

startLevel();

};

function startLevel(){

running = true;
expected = 1;

levelEl.textContent = level;
scoreEl.textContent = score;

createCards();

}

function createCards(){

board.innerHTML="";

let numbers=[];

for(let i=1;i<=level+1;i++){
numbers.push(i);
}

numbers = shuffle(numbers);

numbers.forEach(num=>{

const card = document.createElement("div");
card.className="card";
card.textContent=num;

setTimeout(()=>{
card.classList.add("hidden");
},2000);

card.onclick = ()=>clickCard(card,num);

board.appendChild(card);

});

}

function clickCard(card,num){

if(!running) return;

card.classList.remove("hidden");

if(num === expected){

card.classList.add("correct");

expected++;

if(expected > level+1){

score++;
level++;

setTimeout(startLevel,1000);

}

}else{

running=false;

alert("Wrong! Game Over");

saveScore();

}

}

function shuffle(arr){

for(let i=arr.length-1;i>0;i--){

let j=Math.floor(Math.random()*(i+1));

[arr[i],arr[j]]=[arr[j],arr[i]];

}

return arr;

}

function saveScore(){

fetch("/game-score",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
game:"memory",
name:playerName,
score:score
})
}).then(loadScores);

}

function loadScores(){

fetch("/game-score/memory")
.then(res=>res.json())
.then(data=>{

const list=document.getElementById("scores");
list.innerHTML="";

data.forEach(s=>{

const li=document.createElement("li");
li.textContent=s.player_name+" - "+s.score;
list.appendChild(li);

});

});

}

loadScores();
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let isGameOver = false;

let player = {
    x:280,
    y:450,
    width:40,
    height:40
};

let bullets = [];
let enemies = [];

let score = 0;
let enemySpeed = 2;

let playerName = "";
let gameStarted = false;

/* mouse movement */

document.getElementById("startBtn").onclick = () => {
    playerName = document.getElementById("playerName").value.trim();

    if(!playerName){
        alert("Enter name");
        return;
    }

    document.getElementById("startScreen").style.display = "none";
    gameStarted = true;
};

canvas.addEventListener("mousemove",(e)=>{

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;

    player.x = mouseX - player.width/2;

    if(player.x < 0) player.x = 0;
    if(player.x > canvas.width-player.width)
        player.x = canvas.width-player.width;

});

/* shooting */

document.addEventListener("click",()=>{

    bullets.push({
        x:player.x + player.width/2 - 2,
        y:player.y,
        width:4,
        height:12,
        speed:8
    });

});

/* spawn enemies */

function spawnEnemy(){

    enemies.push({
        x:Math.random()*(canvas.width-40),
        y:-40,
        width:40,
        height:40,
        speed:enemySpeed + Math.random()*2
    });

}

setInterval(spawnEnemy,900);

/* update */

function update(){
    if(isGameOver) return;

    bullets.forEach((b,i)=>{
        b.y -= b.speed;

        if(b.y < 0) bullets.splice(i,1);
    });

    enemies.forEach((e,ei)=>{

        e.y += e.speed;

        bullets.forEach((b,bi)=>{

            if(
                b.x < e.x + e.width &&
                b.x + b.width > e.x &&
                b.y < e.y + e.height &&
                b.y + b.height > e.y
            ){

                enemies.splice(ei,1);
                bullets.splice(bi,1);

                score += 10;

                document.getElementById("score").innerText = "Score: "+score;

                /* increase difficulty */

                enemySpeed = 2 + score/100;

            }

        });

        if(e.y > canvas.height){
            enemies.splice(ei,1);
        }

        if(
            player.x < e.x + e.width &&
            player.x + player.width > e.x &&
            player.y < e.y + e.height &&
            player.y + player.height > e.y
        ){

            gameOver();

        }

    });

}

function gameOver(){

    if(!gameStarted) return;

    isGameOver = true;

    saveScore(); // ✅ save to leaderboard

    document.getElementById("finalScore").innerText = "Score: " + score;
    document.getElementById("gameOverScreen").style.display = "block";

    bullets = [];
    enemies = [];

    score = 0;
    enemySpeed = 2;

    player.x = canvas.width/2 - player.width/2;

    document.getElementById("score").innerText = "Score: 0";

    gameStarted = false;
}

function saveScore(){
    fetch("/game-score", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            game: "shooter",   // unique game name
            name: playerName,
            score: score
        })
    }).then(loadScores);
}
function loadScores(){
    fetch("/game-score/shooter")
        .then(res=>res.json())
        .then(data=>{
            const list = document.getElementById("scores");
            list.innerHTML = "";

            data.forEach(s=>{
                const li = document.createElement("li");
                li.textContent = s.player_name + " - " + s.score;
                list.appendChild(li);
            });
        });
}
/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* player */

    ctx.fillStyle="cyan";
    ctx.fillRect(player.x,player.y,player.width,player.height);

    /* bullets */

    ctx.fillStyle="yellow";
    bullets.forEach(b=>{
        ctx.fillRect(b.x,b.y,b.width,b.height);
    });

    /* enemies */

    ctx.fillStyle="red";
    enemies.forEach(e=>{
        ctx.fillRect(e.x,e.y,e.width,e.height);
    });

}

document.getElementById("restartBtn").onclick = ()=>{
    document.getElementById("gameOverScreen").style.display = "none";
    gameStarted = true;
    score = 0;
    enemySpeed = 2;
    document.getElementById("score").innerText = "Score: 0";
};

/* game loop */

function loop(){

    update();
    draw();

    requestAnimationFrame(loop);

}
loadScores();
loop();
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const grid = 20;

let snake = [{x:160,y:200}];
let food = {x:300,y:200};

let dx = grid;
let dy = 0;

let score = 0;
let running = false;

let playerName = "";

const scoreEl = document.getElementById("score");

document.getElementById("playBtn").onclick = () => {

    playerName = document.getElementById("playerName").value.trim();

    if(!playerName){
        alert("Enter name");
        return;
    }

    resetGame();
    running = true;

};

function resetGame(){

    snake = [{x:160,y:200}];
    dx = grid;
    dy = 0;
    score = 0;

    createFood();

}

function createFood(){

    food.x = Math.floor(Math.random()*canvas.width/grid)*grid;
    food.y = Math.floor(Math.random()*canvas.height/grid)*grid;

}

document.addEventListener("keydown", e=>{

if(e.key==="ArrowLeft" && dx===0){
dx=-grid;
dy=0;
}

if(e.key==="ArrowUp" && dy===0){
dy=-grid;
dx=0;
}

if(e.key==="ArrowRight" && dx===0){
dx=grid;
dy=0;
}

if(e.key==="ArrowDown" && dy===0){
dy=grid;
dx=0;
}

});

function drawSnake(){

ctx.fillStyle="lime";

snake.forEach(part=>{
ctx.fillRect(part.x,part.y,grid-2,grid-2);
});

}

function drawFood(){

ctx.fillStyle="red";
ctx.fillRect(food.x,food.y,grid-2,grid-2);

}

function moveSnake(){

const head={
x:snake[0].x+dx,
y:snake[0].y+dy
};

snake.unshift(head);

if(head.x===food.x && head.y===food.y){

score+=10;
createFood();

}else{

snake.pop();

}

}

function collision(){

const head=snake[0];

if(
head.x<0 ||
head.y<0 ||
head.x>=canvas.width ||
head.y>=canvas.height
){
gameOver();
}

for(let i=1;i<snake.length;i++){

if(head.x===snake[i].x && head.y===snake[i].y){
gameOver();
}

}

}

function gameOver(){

running=false;
saveScore();
alert("Game Over! Score: "+score);

}

function draw(){

ctx.clearRect(0,0,canvas.width,canvas.height);

if(running){

moveSnake();
collision();

}

drawSnake();
drawFood();

scoreEl.textContent=score;

setTimeout(draw,100);

}

draw();

function saveScore(){

fetch("/game-score",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
game:"snake",
name:playerName,
score:score
})
}).then(loadScores);

}

function loadScores(){

fetch("/game-score/snake")
.then(res=>res.json())
.then(data=>{

const list=document.getElementById("scores");
list.innerHTML="";

data.forEach(s=>{

const li=document.createElement("li");
li.textContent=s.player_name+" - "+s.score;
list.appendChild(li);

});

});

}

loadScores();
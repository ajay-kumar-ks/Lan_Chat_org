const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let towers = [];
let enemies = [];
let bullets = [];

let score = 0;
let playerName = "";
let gameStarted = false;

/* =========================
   PATH
========================= */
const path = [
  { x: 0, y: 250 },
  { x: 200, y: 250 },
  { x: 200, y: 100 },
  { x: 500, y: 100 },
  { x: 500, y: 400 },
  { x: 800, y: 400 },
];

/* =========================
   START BUTTON
========================= */
document.getElementById("startBtn").onclick = () => {
  playerName = document.getElementById("playerName").value.trim();

  if (!playerName) {
    alert("Enter name");
    return;
  }

  document.getElementById("startScreen").style.display = "none";

  gameStarted = true;

  startSpawning();
};

/* =========================
   PLACE TOWER
========================= */
canvas.addEventListener("click", (e) => {
  if (!gameStarted) return;

  const rect = canvas.getBoundingClientRect();

  towers.push({
    x: e.clientX - rect.left,
    y: e.clientY - rect.top,
    range: 120,
  });
});

/* =========================
   SPAWN ENEMIES
========================= */
let spawnInterval;

function spawnEnemy() {
  enemies.push({
    x: path[0].x,
    y: path[0].y,
    pathIndex: 0,
    health: 3,
    speed: 1,
  });
}

function startSpawning() {
  spawnInterval = setInterval(() => {
    if (!gameStarted) return;
    spawnEnemy();
  }, 2000);
}

/* =========================
   UPDATE
========================= */
function update() {
  if (!gameStarted) return;

  /* move enemies */
  enemies.forEach((enemy, ei) => {
    let target = path[enemy.pathIndex + 1];
    if (!target) return;

    let dx = target.x - enemy.x;
    let dy = target.y - enemy.y;
    let dist = Math.sqrt(dx * dx + dy * dy);

    enemy.x += (dx / dist) * enemy.speed;
    enemy.y += (dy / dist) * enemy.speed;

    if (dist < 5) {
      enemy.pathIndex++;
    }

    // 💀 reached end → game over
    if (enemy.pathIndex >= path.length - 1) {
      gameOver();
    }
  });

  /* shooting */
  towers.forEach((tower) => {
    enemies.forEach((enemy) => {
      let dx = enemy.x - tower.x;
      let dy = enemy.y - tower.y;
      let dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < tower.range) {
        bullets.push({
          x: tower.x,
          y: tower.y,
          target: enemy,
        });
      }
    });
  });

  /* bullets */
  bullets.forEach((b, bi) => {
    if (!b.target) return;

    let dx = b.target.x - b.x;
    let dy = b.target.y - b.y;
    let dist = Math.sqrt(dx * dx + dy * dy);

    b.x += (dx / dist) * 5;
    b.y += (dy / dist) * 5;

    if (dist < 10) {
      b.target.health--;

      if (b.target.health <= 0) {
        let index = enemies.indexOf(b.target);

        if (index > -1) {
          enemies.splice(index, 1);
          score += 10;

          document.getElementById("score").innerText =
            "Score: " + score;
        }
      }

      bullets.splice(bi, 1);
    }
  });
}

/* =========================
   GAME OVER
========================= */
function gameOver() {
  gameStarted = false;
  clearInterval(spawnInterval);

  saveScore();

  alert("Game Over! Score: " + score);
  location.reload();
}

/* =========================
   DRAW
========================= */
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  /* path */
  ctx.strokeStyle = "gray";
  ctx.lineWidth = 40;

  ctx.beginPath();
  ctx.moveTo(path[0].x, path[0].y);

  path.forEach((p) => {
    ctx.lineTo(p.x, p.y);
  });

  ctx.stroke();

  /* towers */
  ctx.fillStyle = "cyan";
  towers.forEach((t) => {
    ctx.beginPath();
    ctx.arc(t.x, t.y, 15, 0, Math.PI * 2);
    ctx.fill();
  });

  /* enemies */
  ctx.fillStyle = "red";
  enemies.forEach((e) => {
    ctx.beginPath();
    ctx.arc(e.x, e.y, 12, 0, Math.PI * 2);
    ctx.fill();
  });

  /* bullets */
  ctx.fillStyle = "yellow";
  bullets.forEach((b) => {
    ctx.beginPath();
    ctx.arc(b.x, b.y, 5, 0, Math.PI * 2);
    ctx.fill();
  });
}

/* =========================
   LOOP
========================= */
function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

loop();

/* =========================
   LEADERBOARD
========================= */
function loadScores() {
  fetch("/game-score/tower")
    .then((res) => res.json())
    .then((data) => {
      const list = document.getElementById("scores");
      list.innerHTML = "";

      data.sort((a, b) => b.score - a.score);

      data.forEach((s, index) => {
        const li = document.createElement("li");
        li.textContent =
          (index + 1) + ". " + s.player_name + " - " + s.score;
        list.appendChild(li);
      });
    })
    .catch(() => console.log("Leaderboard error"));
}

function saveScore() {
  fetch("/game-score", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      game: "tower",
      name: playerName,
      score: score,
    }),
  }).then(loadScores);
}

/* =========================
   INIT
========================= */
loadScores();
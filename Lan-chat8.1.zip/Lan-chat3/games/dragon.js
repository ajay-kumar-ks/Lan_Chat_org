const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let obstacle1 = new Image();
let obstacle2 = new Image();
obstacle1.src = "assets/obstacle1.png";
obstacle2.src = "assets/obstacle2.png";

let gameStarted = false;
let playerName = "";

/* character state */
let state = "run";

/* image sets */
const characters = {
  hrishi: { run: new Image(), jump: new Image(), hit: new Image() },
  perla: { run: new Image(), jump: new Image(), hit: new Image() },
  adon: { run: new Image(), jump: new Image(), hit: new Image() },
  alen: { run: new Image(), jump: new Image(), hit: new Image() },
  jith: { run: new Image(), jump: new Image(), hit: new Image() },
  rohith: { run: new Image(), jump: new Image(), hit: new Image() },
  pookkada: { run: new Image(), jump: new Image(), hit: new Image() },
  diks: { run: new Image(), jump: new Image(), hit: new Image() },
  vim: { run: new Image(), jump: new Image(), hit: new Image() },
};

/* character images */
characters.hrishi.run.src = "assets/hrishi_run.jpeg";
characters.hrishi.jump.src = "assets/hrishi_jump.jpeg";
characters.hrishi.hit.src = "assets/hrishi_hit.jpeg";

characters.perla.run.src = "assets/perla_run.jpeg";
characters.perla.jump.src = "assets/perla_jump.jpeg";
characters.perla.hit.src = "assets/perla_hit.jpeg";

characters.adon.run.src = "assets/adon_run.jpeg";
characters.adon.jump.src = "assets/adon_jump.jpeg";
characters.adon.hit.src = "assets/adon_hit.jpeg";

characters.alen.run.src = "assets/alen_run.jpeg";
characters.alen.jump.src = "assets/alen_jump.jpeg";
characters.alen.hit.src = "assets/alen_hit.jpeg";

characters.jith.run.src = "assets/jith_run.jpeg";
characters.jith.jump.src = "assets/jith_jump.jpeg";
characters.jith.hit.src = "assets/jith_hit.jpeg";

characters.diks.run.src = "assets/diks_run.jpeg";
characters.diks.jump.src = "assets/diks_jump.jpeg";
characters.diks.hit.src = "assets/diks_hit.jpeg";

characters.pookkada.run.src = "assets/pookkada_run.jpeg";
characters.pookkada.jump.src = "assets/pookkada_jump.jpeg";
characters.pookkada.hit.src = "assets/pookkada_hit.jpeg";

characters.rohith.run.src = "assets/rohith_run.jpeg";
characters.rohith.jump.src = "assets/rohith_jump.jpeg";
characters.rohith.hit.src = "assets/rohith_hit.jpeg";

characters.vim.run.src = "assets/vim_run.jpeg";
characters.vim.jump.src = "assets/vim_jump.jpeg";
characters.vim.hit.src = "assets/vim_hit.jpeg";

let currentCharacter = "hrishi";
obstacle1.src = "assets/elephant.png";

/* player */
let player = {
  x: 80,
  y: 160,
  width: 50,
  height: 50,
  vy: 0,
  gravity: 0.7,
  jump: -13.5,
  grounded: true,
};

/* obstacles */
let obstacles = [];
let score = 0;
let speed = 6;
let gameOver = false;

/* jump */
document.addEventListener("keydown", (e) => {
  if ((e.code === "Space" || e.code === "ArrowUp") && player.grounded && !gameOver && gameStarted) {
    player.vy = player.jump;
    player.grounded = false;
    state = "jump";
  }
});

// character select dropdown
document.getElementById("characterSelect")?.addEventListener("change", (e) => {
    currentCharacter = e.target.value;
});
/* spawn obstacles */
function spawnObstacle() {
  if (!gameStarted || gameOver) return;

  let lastObstacle = obstacles[obstacles.length - 1];
  let minGap = 250 + Math.random() * 200;

  if (lastObstacle && lastObstacle.x > canvas.width - minGap) {
    setTimeout(spawnObstacle, 200);
    return;
  }

  let type = Math.floor(Math.random() * 4);

  if (type === 0) obstacles.push({x: canvas.width, y: 155 + Math.random() * 8, width:40, height:40, img: obstacle1, hitbox:{x:6,y:8,width:28,height:30}});
  if (type === 1) for(let i=0;i<2;i++) obstacles.push({x: canvas.width + i * (40 + Math.random()*15), y:160, width:40, height:40, img: obstacle1, hitbox:{x:6,y:8,width:28,height:30}});
  if (type === 2) for(let i=0;i<3;i++) obstacles.push({x: canvas.width + i * (40 + Math.random()*15), y:160, width:40, height:40, img: obstacle1, hitbox:{x:6,y:8,width:28,height:30}});
  if (type === 3) obstacles.push({x: canvas.width, y:165, width:60, height:35, img: obstacle2, hitbox:{x:6,y:8,width:28,height:30}});

  let nextSpawn = 900 + Math.random() * 700;
  setTimeout(spawnObstacle, nextSpawn);
}

/* update */
function update() {
  if (!gameStarted || gameOver) return;

  player.vy += player.gravity;
  player.y += player.vy;

  if (player.y >= 160) { player.y = 160; player.vy = 0; player.grounded = true; state="run"; }

  obstacles.forEach((o,i)=>{
    o.x -= speed;
    let hx = o.x + o.hitbox.x, hy = o.y + o.hitbox.y, hw = o.hitbox.width, hh = o.hitbox.height;

    if (player.x < hx + hw && player.x + player.width > hx && player.y < hy + hh && player.y + player.height > hy){
      state="hit"; gameOver=true;
      document.getElementById("finalScore").innerText="Score: "+score;
      document.getElementById("gameOverScreen").style.display="block";
      saveScore();
    }

    if(o.x < -100) obstacles.splice(i,1);
  });

  score++;
  document.getElementById("score").innerText = score;
  if(score%500===0) speed+=0.5;
}

/* draw */
function draw() {
  ctx.clearRect(0,0,canvas.width,canvas.height);

  /* ground */
  ctx.strokeStyle="#374151";
  ctx.beginPath(); ctx.moveTo(0,200); ctx.lineTo(canvas.width,200); ctx.stroke();

  /* player square */
  ctx.fillStyle="#1f2937";
  ctx.fillRect(player.x,player.y,player.width,player.height);

  /* character image */
  let img = characters[currentCharacter][state];
  if(img.complete) ctx.drawImage(img, player.x+3, player.y+3, player.width-6, player.height-6);

  /* obstacles */
  obstacles.forEach(o => ctx.drawImage(o.img,o.x,o.y,o.width,o.height));
}

/* loop */
function loop(){
  if(currentCharacter==="hrishi") obstacle1.src="assets/elephant.png";
  else if(currentCharacter==="perla") obstacle1.src="assets/bomb.png";
  else if(currentCharacter==="adon") obstacle1.src="assets/nabeel.jpeg";
  else if(currentCharacter==="alen") obstacle1.src="assets/obstacle1.png";
  else if(currentCharacter==="jith") obstacle1.src="assets/obstacle1.png";
  else if(currentCharacter==="diks") obstacle1.src="assets/obstacle1.png";
  else if(currentCharacter==="pookkada") obstacle1.src="assets/flower.png";
  else if(currentCharacter==="rohith") obstacle1.src="assets/obstacle1.png";
  else if(currentCharacter==="vim") obstacle1.src="assets/obstacle1.png";

  update();
  draw();
  requestAnimationFrame(loop);
}

/* leaderboard */
function loadScores() {
  fetch("/game-score/runner")
  .then(res=>res.json())
  .then(data=>{
    const list = document.getElementById("scores");
    list.innerHTML="";
    data.forEach(s=>{
      const li=document.createElement("li");
      li.textContent=s.player_name + " - " + s.score;
      list.appendChild(li);
    });
  });
}

function saveScore() {
  fetch("/game-score", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify({game:"runner", name:playerName, score:score})
  }).then(loadScores);
}

/* start button */
document.getElementById("startBtn").addEventListener("click", (e) => {
    e.preventDefault(); // stops the page from scrolling
    playerName = document.getElementById("playerName").value.trim();

    if (!playerName) {
        alert("Enter name");
        return;
    }

    document.getElementById("startScreen").style.display = "none";
    gameStarted = true;

    spawnObstacle();
});

/* restart button */
document.getElementById("restartBtn").addEventListener("click", (e) => {
    e.preventDefault(); // prevent scrolling

    obstacles = [];
    score = 0;
    speed = 6;

    player.y = 160;
    player.vy = 0;
    player.grounded = true;

    gameOver = false;

    document.getElementById("score").innerText = "Score: 0";
    document.getElementById("gameOverScreen").style.display = "none";

    spawnObstacle();
});

// prevent page scroll for Space and ArrowUp globally
window.addEventListener("keydown", function(e) {
    if (e.code === "Space" || e.code === "ArrowUp") {
        e.preventDefault(); // stops scrolling
    }

    // jump logic
    if ((e.code === "Space" || e.code === "ArrowUp") && player.grounded && !gameOver && gameStarted) {
        player.vy = player.jump;
        player.grounded = false;
        state = "jump";
    }
});

/* start loop */
loop();
loadScores();
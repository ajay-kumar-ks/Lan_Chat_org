const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const tile = 50;

/* maze layout */

const maze = [
[0,1,0,0,0,0,1,0,0,0],
[0,1,0,1,1,0,1,0,1,0],
[0,0,0,1,0,0,0,0,1,0],
[1,1,0,1,0,1,1,0,1,0],
[0,0,0,0,0,1,0,0,0,0],
[0,1,1,1,0,1,0,1,1,0],
[0,0,0,1,0,0,0,1,0,0],
[1,1,0,1,1,1,0,1,0,1],
[0,0,0,0,0,0,0,0,0,1],
[0,1,1,1,1,1,1,1,0,0]
];

/* player */

let player = {
    x:0,
    y:0
};

/* exit */

let exit = {
    x:9,
    y:9
};

/* movement */

document.addEventListener("keydown",(e)=>{

    let newX = player.x;
    let newY = player.y;

    if(e.key === "ArrowUp") newY--;
    if(e.key === "ArrowDown") newY++;
    if(e.key === "ArrowLeft") newX--;
    if(e.key === "ArrowRight") newX++;

    if(
        newX >= 0 &&
        newY >= 0 &&
        newX < 10 &&
        newY < 10 &&
        maze[newY][newX] === 0
    ){
        player.x = newX;
        player.y = newY;
    }

    if(player.x === exit.x && player.y === exit.y){
        alert("🎉 You Escaped!");
        location.reload();
    }

});

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    for(let y=0;y<10;y++){

        for(let x=0;x<10;x++){

            if(maze[y][x] === 1){

                ctx.fillStyle="#333";
                ctx.fillRect(x*tile,y*tile,tile,tile);

            }else{

                ctx.fillStyle="#111";
                ctx.fillRect(x*tile,y*tile,tile,tile);

            }

        }

    }

    /* exit */

    ctx.fillStyle="green";
    ctx.fillRect(exit.x*tile,exit.y*tile,tile,tile);

    /* player */

    ctx.fillStyle="cyan";
    ctx.fillRect(player.x*tile,player.y*tile,tile,tile);

}

function loop(){

    draw();
    requestAnimationFrame(loop);

}

loop();

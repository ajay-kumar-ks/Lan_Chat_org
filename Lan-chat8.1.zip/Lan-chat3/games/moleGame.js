const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let score = 0;
let timeLeft = 30;

let playerName = "";

const holes = [
    {x:150,y:150},
    {x:300,y:150},
    {x:450,y:150},

    {x:150,y:300},
    {x:300,y:300},
    {x:450,y:300}
];

let moleIndex = 0;

/* spawn mole */
let gameStarted = false;

document.getElementById("startBtn").onclick = () => {
    playerName = document.getElementById("playerName").value.trim();

    if (!playerName) {
        alert("Enter name");
        return;
    }

    document.getElementById("startScreen").style.display = "none";
    gameStarted = true;
};

function spawnMole(){

    moleIndex = Math.floor(Math.random()*holes.length);

}

setInterval(spawnMole,800);

function saveScore() {
    fetch("/game-score", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            game: "mole",   // ✅ unique name
            name: playerName,
            score: score,
        }),
    }).then(loadScores);
}
function loadScores() {
    fetch("/game-score/mole")
        .then((res) => res.json())
        .then((data) => {
            const list = document.getElementById("scores");
            list.innerHTML = "";

            data.forEach((s) => {
                const li = document.createElement("li");
                li.textContent = s.player_name + " - " + s.score;
                list.appendChild(li);
            });
        });
}
document.getElementById("restartBtn").onclick = () => {
    score = 0;
    timeLeft = 30;

    document.getElementById("score").innerText = "Score: 0";
    document.getElementById("time").innerText = "Time: 30";

    document.getElementById("gameOverScreen").style.display = "none";

    gameStarted = true;
};
/* click */

canvas.addEventListener("click",(e)=>{

    if(!gameStarted) return;

    const rect = canvas.getBoundingClientRect();

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const mole = holes[moleIndex];

    const dx = mouseX - mole.x;
    const dy = mouseY - mole.y;

    const distance = Math.sqrt(dx*dx + dy*dy);

    if(distance < 30){

        score += 10;

        document.getElementById("score").innerText =
        "Score: " + score;

        spawnMole();

    }

});

/* timer */

const timer = setInterval(()=>{

    if(!gameStarted) return;

    timeLeft--;

    document.getElementById("time").innerText =
    "Time: " + timeLeft;

    if(timeLeft <= 0){

        clearInterval(timer);

        saveScore(); // ✅ SAVE SCORE

        document.getElementById("finalScore").innerText =
        "Score: " + score;

        document.getElementById("gameOverScreen").style.display = "block";

    }

},1000);

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* holes */

    ctx.fillStyle="#444";

    holes.forEach(h=>{

        ctx.beginPath();
        ctx.arc(h.x,h.y,35,0,Math.PI*2);
        ctx.fill();

    });

    /* mole */

    const mole = holes[moleIndex];

    ctx.beginPath();
    ctx.arc(mole.x,mole.y,25,0,Math.PI*2);
    ctx.fillStyle="brown";
    ctx.fill();

    requestAnimationFrame(draw);

}

loadScores();
draw();
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const COLS = 10;
const ROWS = 20;
const SIZE = 25;

let board = [];
let score = 0;
let running = false;
let playerName = "";

const scoreEl = document.getElementById("score");

/* ======================
   START BUTTON
====================== */
document.getElementById("playBtn").onclick = () => {
  playerName = document.getElementById("playerName").value.trim();

  if (!playerName) {
    alert("Enter name");
    return;
  }

  document.getElementById("startScreen").style.display = "none";

  score = 0;
  createBoard();
  newPiece();
  running = true;
};

/* ======================
   BOARD
====================== */
function createBoard() {
  board = [];
  for (let r = 0; r < ROWS; r++) {
    board[r] = [];
    for (let c = 0; c < COLS; c++) {
      board[r][c] = 0;
    }
  }
}

/* ======================
   PIECE
====================== */
let piece;

function newPiece() {
  piece = {
    x: 4,
    y: 0,
    shape: [
      [1, 1],
      [1, 1],
    ],
  };

  // 💀 Game Over check
  if (collision()) {
    running = false;
    saveScore();
    alert("Game Over! Score: " + score);
    location.reload();
  }
}

/* ======================
   CONTROLS
====================== */
document.addEventListener("keydown", (e) => {
  if (!running) return;

  if (e.key === "ArrowLeft") piece.x--;
  if (e.key === "ArrowRight") piece.x++;
  if (e.key === "ArrowDown") piece.y++;
});

/* ======================
   DRAW
====================== */
function drawCell(x, y, color) {
  ctx.fillStyle = color;
  ctx.fillRect(x * SIZE, y * SIZE, SIZE - 1, SIZE - 1);
}

function drawBoard() {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      if (board[r][c]) {
        drawCell(c, r, "cyan");
      }
    }
  }
}

function drawPiece() {
  for (let r = 0; r < piece.shape.length; r++) {
    for (let c = 0; c < piece.shape[r].length; c++) {
      if (piece.shape[r][c]) {
        drawCell(piece.x + c, piece.y + r, "orange");
      }
    }
  }
}

/* ======================
   LOGIC
====================== */
function collision() {
  for (let r = 0; r < piece.shape.length; r++) {
    for (let c = 0; c < piece.shape[r].length; c++) {
      if (piece.shape[r][c]) {
        let newX = piece.x + c;
        let newY = piece.y + r;

        if (newY >= ROWS || board[newY]?.[newX]) {
          return true;
        }
      }
    }
  }
  return false;
}

function merge() {
  for (let r = 0; r < piece.shape.length; r++) {
    for (let c = 0; c < piece.shape[r].length; c++) {
      if (piece.shape[r][c]) {
        board[piece.y + r][piece.x + c] = 1;
      }
    }
  }
}

function clearRows() {
  for (let r = ROWS - 1; r >= 0; r--) {
    if (board[r].every((v) => v === 1)) {
      board.splice(r, 1);
      board.unshift(new Array(COLS).fill(0));
      score += 10;
    }
  }
}

function update() {
  if (!running) return;

  piece.y++;

  if (collision()) {
    piece.y--;
    merge();
    clearRows();
    newPiece();
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBoard();
  drawPiece();
  scoreEl.textContent = score;
}

function gameLoop() {
  update();
  draw();
  setTimeout(gameLoop, 400);
}

/* ======================
   LEADERBOARD
====================== */
function loadScores() {
  fetch("/game-score/tetris")
    .then((res) => res.json())
    .then((data) => {
      const list = document.getElementById("scores");
      list.innerHTML = "";

      data.sort((a, b) => b.score - a.score);

      data.forEach((s, index) => {
        const li = document.createElement("li");
        li.textContent =
          (index + 1) + ". " + s.player_name + " - " + s.score;
        list.appendChild(li);
      });
    })
    .catch(() => console.log("Leaderboard error"));
}

function saveScore() {
  fetch("/game-score", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      game: "tetris",
      name: playerName,
      score: score,
    }),
  }).then(loadScores);
}

/* ======================
   INIT
====================== */
createBoard();
newPiece();
gameLoop();
loadScores();
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const rows = 4;
const cols = 4;

const cardSize = 100;

let cards = [];
let flipped = [];
let moves = 0;

/* create card values */

let values = ["A","A","B","B","C","C","D","D","E","E","F","F","G","G","H","H"];

/* shuffle */

values.sort(()=>Math.random()-0.5);

/* create grid */

for(let r=0;r<rows;r++){

    for(let c=0;c<cols;c++){

        cards.push({
            x:c*(cardSize+10)+80,
            y:r*(cardSize+10)+40,
            value:values[r*cols+c],
            flipped:false,
            matched:false
        });

    }

}

/* click */

canvas.addEventListener("click",(e)=>{

    const rect = canvas.getBoundingClientRect();

    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    cards.forEach(card=>{

        if(
            mx > card.x &&
            mx < card.x + cardSize &&
            my > card.y &&
            my < card.y + cardSize &&
            !card.flipped &&
            !card.matched &&
            flipped.length < 2
        ){

            card.flipped = true;
            flipped.push(card);

        }

    });

    if(flipped.length === 2){

        moves++;

        document.getElementById("moves").innerText =
        "Moves: " + moves;

        if(flipped[0].value === flipped[1].value){

            flipped[0].matched = true;
            flipped[1].matched = true;

            flipped = [];

        }else{

            setTimeout(()=>{

                flipped[0].flipped = false;
                flipped[1].flipped = false;

                flipped = [];

            },800);

        }

    }

});

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    cards.forEach(card=>{

        if(card.flipped || card.matched){

            ctx.fillStyle="#22c55e";
            ctx.fillRect(card.x,card.y,cardSize,cardSize);

            ctx.fillStyle="black";
            ctx.font="40px Arial";
            ctx.textAlign="center";
            ctx.fillText(
                card.value,
                card.x + cardSize/2,
                card.y + 65
            );

        }else{

            ctx.fillStyle="#3b82f6";
            ctx.fillRect(card.x,card.y,cardSize,cardSize);

        }

    });

    requestAnimationFrame(draw);

}

draw();

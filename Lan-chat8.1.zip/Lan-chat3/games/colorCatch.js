const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player = {
    x:260,
    y:460,
    width:100,
    height:20
};

let blocks = [];
let score = 0;
let speed = 2;
let gameOver = false;

let playerName = "";
let gameStarted = false;
let scoreSaved = false;

/* mouse movement */

canvas.addEventListener("mousemove",(e)=>{

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;

    player.x = mouseX - player.width/2;

    if(player.x < 0) player.x = 0;
    if(player.x > canvas.width-player.width)
        player.x = canvas.width-player.width;

});

/* spawn blocks */

function spawnBlock(){

    blocks.push({
        x:Math.random()*(canvas.width-30),
        y:-30,
        size:30,
        speed:speed,
        color:`hsl(${Math.random()*360},70%,50%)`
    });

}

setInterval(spawnBlock,800);

function loadScores() {
    fetch("/game-score/block-catcher")
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("scores");
            list.innerHTML = "";

            data.sort((a,b)=>b.score-a.score);

            data.slice(0,10).forEach(s => {
                const li = document.createElement("li");
                li.textContent = s.player_name + " - " + s.score;
                list.appendChild(li);
            });
        });
}

function saveScore() {
    if(scoreSaved) return;

    fetch("/game-score", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            game: "block-catcher",
            name: playerName,
            score: score
        })
    }).then(() => {
        scoreSaved = true;
        loadScores();
    });
}

document.getElementById("startBtn").onclick = () => {
    playerName = document.getElementById("playerName").value.trim();

    if(!playerName){
        alert("Enter name");
        return;
    }

    gameStarted = true;
};
/* update */

function update(){

    if(gameOver) return;

    blocks.forEach((b,i)=>{

        b.y += b.speed;

        /* catch */

        if(
            b.x < player.x + player.width &&
            b.x + b.size > player.x &&
            b.y + b.size > player.y
        ){

            blocks.splice(i,1);

            score += 10;

            document.getElementById("score").innerText =
            "Score: " + score;

            speed = 2 + score/100;

        }

        /* miss */

        if(b.y > canvas.height){

            gameOver = true;

            saveScore();
            alert("Game Over! Score: "+score);

            location.reload();

        }

    });

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* player */

    ctx.fillStyle="cyan";
    ctx.fillRect(player.x,player.y,player.width,player.height);

    /* blocks */

    blocks.forEach(b=>{

        ctx.fillStyle = b.color;
        ctx.fillRect(b.x,b.y,b.size,b.size);

    });

}

/* game loop */

function loop(){

    if(!gameStarted){
        requestAnimationFrame(loop);
        return;
    }

    update();
    draw();

    requestAnimationFrame(loop);
}
loadScores();
loop();

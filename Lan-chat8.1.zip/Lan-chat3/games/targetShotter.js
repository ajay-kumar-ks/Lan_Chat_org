const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let score = 0;
let timeLeft = 30;
let playerName = "";
let gameStarted = false;

let target = {
  x: 100,
  y: 100,
  radius: 25,
};

/* =========================
   START BUTTON
========================= */
document.getElementById("startBtn").onclick = () => {
  playerName = document.getElementById("playerName").value.trim();

  if (!playerName) {
    alert("Enter name");
    return;
  }

  document.getElementById("startScreen").style.display = "none";

  gameStarted = true;

  startTimer();
  startTargetMovement();
};

/* =========================
   MOVE TARGET
========================= */
function moveTarget() {
  target.x = Math.random() * (canvas.width - 60) + 30;
  target.y = Math.random() * (canvas.height - 60) + 30;
}

let targetInterval;

function startTargetMovement() {
  targetInterval = setInterval(() => {
    if (!gameStarted) return;
    moveTarget();
  }, 1000);
}

/* =========================
   CLICK DETECTION
========================= */
canvas.addEventListener("click", (e) => {
  if (!gameStarted) return;

  const rect = canvas.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;

  const dx = mouseX - target.x;
  const dy = mouseY - target.y;

  const distance = Math.sqrt(dx * dx + dy * dy);

  if (distance < target.radius) {
    score += 10;
    document.getElementById("score").innerText = "Score: " + score;
    moveTarget();
  }
});

/* =========================
   TIMER
========================= */
let timer;

function startTimer() {
  timer = setInterval(() => {
    if (!gameStarted) return;

    timeLeft--;
    document.getElementById("time").innerText = "Time: " + timeLeft;

    if (timeLeft <= 0) {
      clearInterval(timer);
      clearInterval(targetInterval);

      saveScore();

      alert("Game Over! Score: " + score);
      location.reload();
    }
  }, 1000);
}

/* =========================
   DRAW
========================= */
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // target outer
  ctx.beginPath();
  ctx.arc(target.x, target.y, target.radius, 0, Math.PI * 2);
  ctx.fillStyle = "red";
  ctx.fill();

  // target inner
  ctx.beginPath();
  ctx.arc(target.x, target.y, 10, 0, Math.PI * 2);
  ctx.fillStyle = "white";
  ctx.fill();

  requestAnimationFrame(draw);
}

draw();

/* =========================
   LEADERBOARD
========================= */
function loadScores() {
  fetch("/game-score/target")
    .then((res) => res.json())
    .then((data) => {
      const list = document.getElementById("scores");
      list.innerHTML = "";

      // sort highest first
      data.sort((a, b) => b.score - a.score);

      data.forEach((s, index) => {
        const li = document.createElement("li");
        li.textContent =
          (index + 1) + ". " + s.player_name + " - " + s.score;
        list.appendChild(li);
      });
    })
    .catch(() => {
      console.log("Leaderboard not loading (check backend)");
    });
}

function saveScore() {
  fetch("/game-score", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      game: "target",
      name: playerName,
      score: score,
    }),
  }).then(loadScores);
}

/* =========================
   LOAD SCORES ON PAGE LOAD
========================= */
loadScores();
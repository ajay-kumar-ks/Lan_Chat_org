const dragon = document.getElementById("dragon");
const obstacle = document.getElementById("obstacle");
const scoreEl = document.getElementById("score");
const playBtn = document.getElementById("playBtn");
const scoresList = document.getElementById("scores");

let score = 0;
let speed = 5;
let gameRunning = false;
let obstacleX = 600;
let playerName = "";

function loadScores(){

fetch("/game-score/dragon")
.then(res=>res.json())
.then(data=>{

const list=document.getElementById("scores");

list.innerHTML="";

data.forEach(s=>{

const li=document.createElement("li");
li.textContent = s.player_name + " - " + s.score;

list.appendChild(li);

});

});

}
function saveScore(){

fetch("/game-score",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
game:"dragon",
name:playerName,
score:score
})
}).then(loadScores);

}

function jump(){

    if(!dragon.classList.contains("jump")){
        dragon.classList.add("jump");

        setTimeout(()=>{
            dragon.classList.remove("jump");
        },500);
    }

}

document.addEventListener("keydown",e=>{
    if(e.code==="Space") jump();
});

document.addEventListener("click",jump);

playBtn.onclick=()=>{

    playerName=document.getElementById("playerName").value.trim();

    if(!playerName){
        alert("Enter name");
        return;
    }

    score=0;
    speed=5;
    obstacleX=600;
    gameRunning=true;

};

function gameLoop(){

    if(!gameRunning){
        requestAnimationFrame(gameLoop);
        return;
    }

    obstacleX-=speed;

    if(obstacleX<-30){
        obstacleX=600;
        score++;
        speed+=0.2;
    }

    obstacle.style.right=(600-obstacleX)+"px";

    const dragonTop=parseInt(window.getComputedStyle(dragon).getPropertyValue("bottom"));

    if(obstacleX<100 && obstacleX>50 && dragonTop<40){

        gameRunning=false;

        saveScore(playerName,score);
        loadScores();

        alert("Game Over! Score: "+score);

    }

    scoreEl.textContent=score;

    requestAnimationFrame(gameLoop);

}

loadScores();
gameLoop();
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let level = 1;
let score = 0;
let moves = 0;

let rows = 4;
let cols = 4;

const cardSize = 80;

let cards = [];
let flipped = [];

/* create level */

function createLevel(){

    cards = [];
    flipped = [];

    let total = rows * cols;

    let values = [];

    for(let i=0;i<total/2;i++){

        let letter = String.fromCharCode(65+i);

        values.push(letter);
        values.push(letter);

    }

    values.sort(()=>Math.random()-0.5);

    for(let r=0;r<rows;r++){

        for(let c=0;c<cols;c++){

            cards.push({
                x:c*(cardSize+10)+60,
                y:r*(cardSize+10)+40,
                value:values[r*cols+c],
                flipped:false,
                matched:false
            });

        }

    }

}

createLevel();

/* click */

canvas.addEventListener("click",(e)=>{

    const rect = canvas.getBoundingClientRect();

    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    cards.forEach(card=>{

        if(
            mx > card.x &&
            mx < card.x + cardSize &&
            my > card.y &&
            my < card.y + cardSize &&
            !card.flipped &&
            !card.matched &&
            flipped.length < 2
        ){

            card.flipped = true;
            flipped.push(card);

        }

    });

    if(flipped.length === 2){

        moves++;
        document.getElementById("moves").innerText = moves;

        if(flipped[0].value === flipped[1].value){

            flipped[0].matched = true;
            flipped[1].matched = true;

            score += 10;

            document.getElementById("score").innerText = score;

            flipped = [];

            checkWin();

        }else{

            setTimeout(()=>{

                flipped[0].flipped = false;
                flipped[1].flipped = false;

                flipped = [];

            },700);

        }

    }

});

/* check win */

function checkWin(){

    let win = cards.every(c=>c.matched);

    if(win){

        level++;

        if(level === 2){
            rows = 4;
            cols = 6;
        }
        else if(level === 3){
            rows = 6;
            cols = 6;
        }
        else{
            alert("🏆 You completed all levels!");
            location.reload();
            return;
        }

        document.getElementById("level").innerText = level;

        createLevel();

    }

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    cards.forEach(card=>{

        if(card.flipped || card.matched){

            ctx.fillStyle="#22c55e";
            ctx.fillRect(card.x,card.y,cardSize,cardSize);

            ctx.fillStyle="black";
            ctx.font="30px Arial";
            ctx.textAlign="center";
            ctx.fillText(
                card.value,
                card.x + cardSize/2,
                card.y + 50
            );

        }else{

            ctx.fillStyle="#3b82f6";
            ctx.fillRect(card.x,card.y,cardSize,cardSize);

        }

    });

    requestAnimationFrame(draw);

}

draw();

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let score = 0;
let timeLeft = 30;

const holes = [
    {x:150,y:150},
    {x:300,y:150},
    {x:450,y:150},

    {x:150,y:300},
    {x:300,y:300},
    {x:450,y:300}
];

let moleIndex = 0;

/* spawn mole */

function spawnMole(){

    moleIndex = Math.floor(Math.random()*holes.length);

}

setInterval(spawnMole,800);

/* click */

canvas.addEventListener("click",(e)=>{

    const rect = canvas.getBoundingClientRect();

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const mole = holes[moleIndex];

    const dx = mouseX - mole.x;
    const dy = mouseY - mole.y;

    const distance = Math.sqrt(dx*dx + dy*dy);

    if(distance < 30){

        score += 10;

        document.getElementById("score").innerText =
        "Score: " + score;

        spawnMole();

    }

});

/* timer */

const timer = setInterval(()=>{

    timeLeft--;

    document.getElementById("time").innerText =
    "Time: " + timeLeft;

    if(timeLeft <= 0){

        clearInterval(timer);

        alert("Game Over! Score: "+score);

        location.reload();

    }

},1000);

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* holes */

    ctx.fillStyle="#444";

    holes.forEach(h=>{

        ctx.beginPath();
        ctx.arc(h.x,h.y,35,0,Math.PI*2);
        ctx.fill();

    });

    /* mole */

    const mole = holes[moleIndex];

    ctx.beginPath();
    ctx.arc(mole.x,mole.y,25,0,Math.PI*2);
    ctx.fillStyle="brown";
    ctx.fill();

    requestAnimationFrame(draw);

}

draw();
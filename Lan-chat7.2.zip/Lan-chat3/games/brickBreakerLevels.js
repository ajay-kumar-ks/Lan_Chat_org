const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let score = 0;
let level = 1;

let paddle = {
    x:300,
    y:460,
    width:120,
    height:15
};

let ball = {
    x:350,
    y:300,
    radius:8,
    dx:3,
    dy:-3
};

let bricks = [];
let rows = 3;
let cols = 6;

/* create bricks */

function createBricks(){

    bricks = [];

    for(let r=0;r<rows;r++){

        bricks[r] = [];

        for(let c=0;c<cols;c++){

            bricks[r][c] = {
                x:c*100 + 40,
                y:r*40 + 40,
                width:80,
                height:20,
                visible:true
            };

        }

    }

}

/* first level */

createBricks();

/* mouse control */

canvas.addEventListener("mousemove",(e)=>{

    const rect = canvas.getBoundingClientRect();

    const mouseX = e.clientX - rect.left;

    paddle.x = mouseX - paddle.width/2;

    if(paddle.x < 0) paddle.x = 0;
    if(paddle.x > canvas.width - paddle.width)
        paddle.x = canvas.width - paddle.width;

});

/* next level */

function nextLevel(){

    level++;

    if(level > 3){

        alert("🏆 You Win! Score: " + score);
        location.reload();
        return;

    }

    document.getElementById("level").innerText = "Level: " + level;

    rows += 1;
    cols += 1;

    ball.dx += 1;
    ball.dy -= 1;

    ball.x = canvas.width/2;
    ball.y = 300;

    createBricks();

}

/* update */

function update(){

    ball.x += ball.dx;
    ball.y += ball.dy;

    if(ball.x < ball.radius || ball.x > canvas.width-ball.radius){
        ball.dx *= -1;
    }

    if(ball.y < ball.radius){
        ball.dy *= -1;
    }

    if(
        ball.x > paddle.x &&
        ball.x < paddle.x + paddle.width &&
        ball.y + ball.radius > paddle.y
    ){
        ball.dy *= -1;
    }

    if(ball.y > canvas.height){

        alert("Game Over! Score: "+score);
        location.reload();

    }

    let remaining = 0;

    bricks.forEach(row=>{

        row.forEach(brick=>{

            if(brick.visible){

                remaining++;

                if(
                    ball.x > brick.x &&
                    ball.x < brick.x + brick.width &&
                    ball.y > brick.y &&
                    ball.y < brick.y + brick.height
                ){

                    ball.dy *= -1;

                    brick.visible = false;

                    score += 10;

                    document.getElementById("score").innerText =
                    "Score: " + score;

                }

            }

        });

    });

    if(remaining === 0){
        nextLevel();
    }

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    ctx.fillStyle="cyan";
    ctx.fillRect(paddle.x,paddle.y,paddle.width,paddle.height);

    ctx.beginPath();
    ctx.arc(ball.x,ball.y,ball.radius,0,Math.PI*2);
    ctx.fillStyle="yellow";
    ctx.fill();

    bricks.forEach(row=>{

        row.forEach(brick=>{

            if(brick.visible){

                ctx.fillStyle="red";
                ctx.fillRect(brick.x,brick.y,brick.width,brick.height);

            }

        });

    });

}

/* game loop */

function loop(){

    update();
    draw();

    requestAnimationFrame(loop);

}

loop();
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const size = 20;
const tile = canvas.width / size;

let maze = [];
let level = 1;
let timeLeft = 60;

let player = {x:0,y:0};
let exit = {x:size-1,y:size-1};

let enemies = [];

/* random maze */

function generateMaze(){

    do{

        maze = [];

        for(let y=0;y<size;y++){

            maze[y] = [];

            for(let x=0;x<size;x++){

                maze[y][x] = Math.random() < 0.28 ? 1 : 0;

            }

        }

        maze[0][0] = 0;
        maze[size-1][size-1] = 0;

    } while(!pathExists());

}

function pathExists(){

    let visited = [];
    let queue = [{x:0,y:0}];

    for(let y=0;y<size;y++){
        visited[y] = [];
        for(let x=0;x<size;x++){
            visited[y][x] = false;
        }
    }

    visited[0][0] = true;

    const dirs = [
        [0,1],[1,0],[0,-1],[-1,0]
    ];

    while(queue.length > 0){

        let current = queue.shift();

        if(current.x === size-1 && current.y === size-1){
            return true;
        }

        for(let d of dirs){

            let nx = current.x + d[0];
            let ny = current.y + d[1];

            if(
                nx >= 0 &&
                ny >= 0 &&
                nx < size &&
                ny < size &&
                !visited[ny][nx] &&
                maze[ny][nx] === 0
            ){

                visited[ny][nx] = true;
                queue.push({x:nx,y:ny});

            }

        }

    }

    return false;

}



/* create enemies */

function spawnEnemies(){

    enemies = [];

    for(let i=0;i<level;i++){

        enemies.push({
            x:Math.floor(Math.random()*size),
            y:Math.floor(Math.random()*size)
        });

    }

}

/* start level */

function startLevel(){

    generateMaze();

    player.x = 0;
    player.y = 0;

    spawnEnemies();

    document.getElementById("level").innerText = level;

}

startLevel();

/* movement */

document.addEventListener("keydown",(e)=>{

    let nx = player.x;
    let ny = player.y;

    if(e.key === "ArrowUp") ny--;
    if(e.key === "ArrowDown") ny++;
    if(e.key === "ArrowLeft") nx--;
    if(e.key === "ArrowRight") nx++;

    if(
        nx >= 0 &&
        ny >= 0 &&
        nx < size &&
        ny < size &&
        maze[ny][nx] === 0
    ){
        player.x = nx;
        player.y = ny;
    }

    if(player.x === exit.x && player.y === exit.y){

        level++;

        timeLeft += 10;

        startLevel();

    }

});

/* enemy movement */

function moveEnemies(){

    enemies.forEach(e=>{

        let dir = Math.floor(Math.random()*4);

        let nx = e.x;
        let ny = e.y;

        if(dir === 0) ny--;
        if(dir === 1) ny++;
        if(dir === 2) nx--;
        if(dir === 3) nx++;

        if(
            nx >= 0 &&
            ny >= 0 &&
            nx < size &&
            ny < size &&
            maze[ny][nx] === 0
        ){
            e.x = nx;
            e.y = ny;
        }

        if(e.x === player.x && e.y === player.y){

            alert("👾 Enemy caught you!");
            location.reload();

        }

    });

}

setInterval(moveEnemies,500);

/* timer */

setInterval(()=>{

    timeLeft--;

    document.getElementById("time").innerText = timeLeft;

    if(timeLeft <= 0){

        alert("⏱ Time Over!");
        location.reload();

    }

},1000);

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    for(let y=0;y<size;y++){

        for(let x=0;x<size;x++){

            if(maze[y][x] === 1){

                ctx.fillStyle="#333";
                ctx.fillRect(x*tile,y*tile,tile,tile);

            }else{

                ctx.fillStyle="#111";
                ctx.fillRect(x*tile,y*tile,tile,tile);

            }

        }

    }

    /* exit */

    ctx.fillStyle="green";
    ctx.fillRect(exit.x*tile,exit.y*tile,tile,tile);

    /* player */

    ctx.fillStyle="cyan";
    ctx.fillRect(player.x*tile,player.y*tile,tile,tile);

    /* enemies */

    ctx.fillStyle="red";

    enemies.forEach(e=>{
        ctx.fillRect(e.x*tile,e.y*tile,tile,tile);
    });

}

/* loop */

function loop(){

    draw();
    requestAnimationFrame(loop);

}

loop();

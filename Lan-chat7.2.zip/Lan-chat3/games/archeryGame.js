const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let score = 0;

let arrow = {
    x:100,
    y:250,
    speed:8,
    active:false
};

let target = {
    x:700,
    y:250,
    radius:40
};

let mouseY = 250;

/* aim with mouse */

canvas.addEventListener("mousemove",(e)=>{

    const rect = canvas.getBoundingClientRect();

    mouseY = e.clientY - rect.top;

});

/* shoot */

canvas.addEventListener("click",()=>{

    if(!arrow.active){

        arrow.active = true;
        arrow.y = mouseY;

    }

});

/* update */

function update(){

    if(arrow.active){

        arrow.x += arrow.speed;

        const dx = arrow.x - target.x;
        const dy = arrow.y - target.y;

        const distance = Math.sqrt(dx*dx + dy*dy);

        if(distance < target.radius){

            score += 10;

            document.getElementById("score").innerText =
            "Score: " + score;

            resetArrow();

        }

        if(arrow.x > canvas.width){
            resetArrow();
        }

    }

}

/* reset */

function resetArrow(){

    arrow.x = 100;
    arrow.active = false;

    target.y = Math.random()*400 + 50;

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* bow */

    ctx.strokeStyle="white";
    ctx.lineWidth=4;

    ctx.beginPath();
    ctx.moveTo(80,mouseY-40);
    ctx.lineTo(80,mouseY+40);
    ctx.stroke();

    /* arrow */

    ctx.strokeStyle="yellow";
    ctx.lineWidth=3;

    ctx.beginPath();
    ctx.moveTo(arrow.x,arrow.y);
    ctx.lineTo(arrow.x+30,arrow.y);
    ctx.stroke();

    /* target */

    ctx.beginPath();
    ctx.arc(target.x,target.y,target.radius,0,Math.PI*2);
    ctx.fillStyle="red";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(target.x,target.y,20,0,Math.PI*2);
    ctx.fillStyle="white";
    ctx.fill();

}

/* loop */

function loop(){

    update();
    draw();

    requestAnimationFrame(loop);

}

loop();

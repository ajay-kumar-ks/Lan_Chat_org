const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player = {
    x:260,
    y:460,
    width:100,
    height:20
};

let blocks = [];
let score = 0;
let speed = 2;
let gameOver = false;

/* mouse movement */

canvas.addEventListener("mousemove",(e)=>{

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;

    player.x = mouseX - player.width/2;

    if(player.x < 0) player.x = 0;
    if(player.x > canvas.width-player.width)
        player.x = canvas.width-player.width;

});

/* spawn blocks */

function spawnBlock(){

    blocks.push({
        x:Math.random()*(canvas.width-30),
        y:-30,
        size:30,
        speed:speed,
        color:`hsl(${Math.random()*360},70%,50%)`
    });

}

setInterval(spawnBlock,800);

/* update */

function update(){

    if(gameOver) return;

    blocks.forEach((b,i)=>{

        b.y += b.speed;

        /* catch */

        if(
            b.x < player.x + player.width &&
            b.x + b.size > player.x &&
            b.y + b.size > player.y
        ){

            blocks.splice(i,1);

            score += 10;

            document.getElementById("score").innerText =
            "Score: " + score;

            speed = 2 + score/100;

        }

        /* miss */

        if(b.y > canvas.height){

            gameOver = true;

            alert("Game Over! Score: "+score);

            location.reload();

        }

    });

}

/* draw */

function draw(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    /* player */

    ctx.fillStyle="cyan";
    ctx.fillRect(player.x,player.y,player.width,player.height);

    /* blocks */

    blocks.forEach(b=>{

        ctx.fillStyle = b.color;
        ctx.fillRect(b.x,b.y,b.size,b.size);

    });

}

/* game loop */

function loop(){

    update();
    draw();

    requestAnimationFrame(loop);

}

loop();
